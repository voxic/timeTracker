import serial
import io
import time
import datetime
import sqlite3

conn = sqlite3.connect('stats.db')

c = conn.cursor()
#c.execute("""DROP TABLE entrys""")
try:
    c.execute("""CREATE TABLE entrys
                (ID INTEGER PRIMARY KEY AUTOINCREMENT, name text, time float, distans int, date text)""")
    print("DB Created")
except:
    print("DB found")

def new_entry(name, time, distans):
    """ Function to create a new entry. 
    """
    
    date = str(datetime.datetime.now())[0:16]
    entry = [name,round(time, 3),distans,date]
    c.execute("""INSERT INTO entrys (name, time, distans, date) VALUES(?,?,?,?)""", entry)
    conn.commit()
    print("\nEntry saved \n\n")

ser = serial.Serial('/dev/cu.usbmodem1441', 115200, timeout=0.1)
sio = io.TextIOWrapper(io.BufferedRWPair(ser, ser))

timer = 0
activeRunner = False
distans = input("Ange distans: ")

while True:
    runner = input("Namn: ")
    activeRunner = True

    while True:
        
        response = ser.readline()

        if('init' in str(response)):
            print("Systemet har startat")

        if("dist" in str(response)):
            print("Gränsvärde: " + str(response).split(":")[1])
            print("Väntar på löpare...")

        if('start' in str(response) and activeRunner == True):
            print("Timer startad")
            timer = time.time()
            activeRunner = False

        if('stop' in str(response) and activeRunner == False):
            print("Timer stoppad")
            print(runner + " Tid: " + str(time.time() - timer))
            new_entry(runner, time.time() - timer, distans)
            activeRunner = False
            break
    