//load modules
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var sqlite3 = require('sqlite3').verbose();
let db = new sqlite3.Database('../stats.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
    console.log('Connected to the SQlite database.');
  });


//set view engine to ejs
app.set('view engine', 'ejs');

//set upp public directory to serve static files
app.use(express.static('public'));

//Initiate bodyParser to parse request body
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());


function getData(fn){
    let sql = `SELECT * FROM entrys
    ORDER BY time`;

    db.all(sql, [], (err, rows) => {
    if (err) {
        fn(err);
    }
        fn(rows);
    });
}


//Routes

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/data', (req, res) =>{
    getData((results)=>{
        res.send(results);
    });
})


// Run server
console.log("Server is listening...")
app.set('port', process.env.PORT || 3000);
app.listen(app.get('port'));