$(document).ready(function () {
    var table30 = $('#dataTable-30').DataTable();
    var table10 = $('#dataTable-10').DataTable();
    $.get( "/data", function() {
 
    })
    .done(function(data, status, xhr) {
        table30.clear();
        table10.clear();                                     
         $.each(data, function (indexInArray, valueOfElement) {
            if(valueOfElement['distans'] == 10){
                table10.row.add( {
                    0:   valueOfElement['name'],
                    1:   valueOfElement['time'],
                    2:   valueOfElement['distans'],
                    3:   valueOfElement['date']
                });
            }
            else{
                table30.row.add( {
                    0:   valueOfElement['name'],
                    1:   valueOfElement['time'],
                    2:   valueOfElement['distans'],
                    3:   valueOfElement['date']
                });
            }
        });
            table30.draw();
            table10.draw();
            table30.responsive.recalc();
            table10.responsive.recalc();
        
    })
    .fail(function(data, status, xhr) {
    
    })
    .always(function(data, status, xhr) {
    
    }); 
});