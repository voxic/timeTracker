# node-express-ejs-bootstrap
Simple bootstrapped project with node, ejs and express
