import serial
import io
import time
from pynput.keyboard import Key, Controller

ser = serial.Serial('/dev/cu.usbmodem14511', 9600, timeout=1)
sio = io.TextIOWrapper(io.BufferedRWPair(ser, ser))

timer = 0
keyboard = Controller()


while True:
    response = ser.readline()

    if('init' in str(response)):
        print("System started")

    if("dist" in str(response)):
        print("Threshold is: " + str(response).split(":")[1])

    if('start' in str(response)):
        print("Timer start")
        timer = time.time()
        keyboard.press('s')
        

    if('stop' in str(response)):
        print("Timer stopped")
        print("Time: " + str(time.time() - timer))
        keyboard.press('s')
    